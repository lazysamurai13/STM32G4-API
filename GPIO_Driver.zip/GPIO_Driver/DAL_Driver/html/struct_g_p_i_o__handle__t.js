var struct_g_p_i_o__handle__t =
[
    [ "pGPIO_Pinconfig", "struct_g_p_i_o__handle__t.html#a031051d02c62d680936f40b71e250d99", null ],
    [ "pGPIOx", "struct_g_p_i_o__handle__t.html#acf00c1720f69a1c534b0bd334d1f5835", null ]
];