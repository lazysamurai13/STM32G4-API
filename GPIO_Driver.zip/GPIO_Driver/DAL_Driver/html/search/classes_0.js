var searchData=
[
  ['gpio_5fhandle_5ft_0',['GPIO_handle_t',['../struct_g_p_i_o__handle__t.html',1,'']]],
  ['gpio_5fpinconfig_5ft_1',['GPIO_Pinconfig_t',['../struct_g_p_i_o___pinconfig__t.html',1,'']]],
  ['gpio_5fregdef_5ft_2',['GPIO_Regdef_t',['../struct_g_p_i_o___regdef__t.html',1,'']]]
];
