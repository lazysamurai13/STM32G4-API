var searchData=
[
  ['lckr_5freg_0',['LCKR_reg',['../struct_g_p_i_o___regdef__t.html#a88c2434d9b7417667ac22f2b300e35ae',1,'GPIO_Regdef_t']]]
];
