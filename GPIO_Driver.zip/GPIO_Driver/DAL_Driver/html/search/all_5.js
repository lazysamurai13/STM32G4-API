var searchData=
[
  ['i2c1_5fpclk_5fen_0',['I2C1_PCLK_EN',['../_d_a_l__stm32g4xx_8h.html#a38b3719d33b55faf15f9b9b08295b353',1,'DAL_stm32g4xx.h']]],
  ['icscr_5freg_1',['ICSCR_reg',['../struct_r_c_c___regdef__t.html#a0260bf42104965fc512c15245a47aa39',1,'RCC_Regdef_t']]],
  ['idr_5freg_2',['IDR_reg',['../struct_g_p_i_o___regdef__t.html#aab87528d032036537a09e21b4c3ab18c',1,'GPIO_Regdef_t']]]
];
