var searchData=
[
  ['icscr_5freg_0',['ICSCR_reg',['../struct_r_c_c___regdef__t.html#a0260bf42104965fc512c15245a47aa39',1,'RCC_Regdef_t']]],
  ['idr_5freg_1',['IDR_reg',['../struct_g_p_i_o___regdef__t.html#aab87528d032036537a09e21b4c3ab18c',1,'GPIO_Regdef_t']]]
];
