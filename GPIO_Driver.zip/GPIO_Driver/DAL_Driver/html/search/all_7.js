var searchData=
[
  ['moder_5freg_0',['MODER_reg',['../struct_g_p_i_o___regdef__t.html#aebfa9b084466438cedb963d15c527b7b',1,'GPIO_Regdef_t']]]
];
