var searchData=
[
  ['odr_5freg_0',['ODR_reg',['../struct_g_p_i_o___regdef__t.html#a999d7b1937bfa600de35de3bf6bd3ef2',1,'GPIO_Regdef_t']]],
  ['ospeedr_5freg_1',['OSPEEDR_reg',['../struct_g_p_i_o___regdef__t.html#ad99196dc779f3d9a54588d1a9476600d',1,'GPIO_Regdef_t']]],
  ['otyper_5freg_2',['OTYPER_reg',['../struct_g_p_i_o___regdef__t.html#a5d10a019892152eccf5a7db2dc9b69e8',1,'GPIO_Regdef_t']]]
];
