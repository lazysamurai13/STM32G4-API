var searchData=
[
  ['bdcr_5freg_0',['BDCR_reg',['../struct_r_c_c___regdef__t.html#a3b435eabfdbff19fcdf671194dcf5520',1,'RCC_Regdef_t']]],
  ['brr_5freg_1',['BRR_reg',['../struct_g_p_i_o___regdef__t.html#ae599d6653e1d53c70642cc640e883d89',1,'GPIO_Regdef_t']]],
  ['bssr_5freg_2',['BSSR_reg',['../struct_g_p_i_o___regdef__t.html#afdf11369234598c2e24340eeb653f5eb',1,'GPIO_Regdef_t']]]
];
