var annotated_dup =
[
    [ "GPIO_handle_t", "struct_g_p_i_o__handle__t.html", "struct_g_p_i_o__handle__t" ],
    [ "GPIO_Pinconfig_t", "struct_g_p_i_o___pinconfig__t.html", "struct_g_p_i_o___pinconfig__t" ],
    [ "GPIO_Regdef_t", "struct_g_p_i_o___regdef__t.html", "struct_g_p_i_o___regdef__t" ],
    [ "RCC_Regdef_t", "struct_r_c_c___regdef__t.html", "struct_r_c_c___regdef__t" ]
];