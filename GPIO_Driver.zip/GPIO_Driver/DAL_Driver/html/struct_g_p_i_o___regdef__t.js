var struct_g_p_i_o___regdef__t =
[
    [ "AFRH_reg", "struct_g_p_i_o___regdef__t.html#adaf5a7109029cb33b4cf775608cb7c9c", null ],
    [ "AFRL_reg", "struct_g_p_i_o___regdef__t.html#a999da4d6a62d3a456f7a2ae8e538d0c0", null ],
    [ "BRR_reg", "struct_g_p_i_o___regdef__t.html#ae599d6653e1d53c70642cc640e883d89", null ],
    [ "BSSR_reg", "struct_g_p_i_o___regdef__t.html#afdf11369234598c2e24340eeb653f5eb", null ],
    [ "IDR_reg", "struct_g_p_i_o___regdef__t.html#aab87528d032036537a09e21b4c3ab18c", null ],
    [ "LCKR_reg", "struct_g_p_i_o___regdef__t.html#a88c2434d9b7417667ac22f2b300e35ae", null ],
    [ "MODER_reg", "struct_g_p_i_o___regdef__t.html#aebfa9b084466438cedb963d15c527b7b", null ],
    [ "ODR_reg", "struct_g_p_i_o___regdef__t.html#a999d7b1937bfa600de35de3bf6bd3ef2", null ],
    [ "OSPEEDR_reg", "struct_g_p_i_o___regdef__t.html#ad99196dc779f3d9a54588d1a9476600d", null ],
    [ "OTYPER_reg", "struct_g_p_i_o___regdef__t.html#a5d10a019892152eccf5a7db2dc9b69e8", null ],
    [ "PUPDR_reg", "struct_g_p_i_o___regdef__t.html#a0e2086e5b92f3e8ba35cbcd506bce63e", null ]
];