var struct_g_p_i_o___pinconfig__t =
[
    [ "Pin_Alt_fn", "struct_g_p_i_o___pinconfig__t.html#a2b1208792079a540d1b64348ea5d30be", null ],
    [ "Pin_mode", "struct_g_p_i_o___pinconfig__t.html#ab6ed5ba87ede8710199cda635d0d3be9", null ],
    [ "Pin_number", "struct_g_p_i_o___pinconfig__t.html#aa2c55e57a27067f5c8f9ef001327bdd9", null ],
    [ "Pin_OP_type", "struct_g_p_i_o___pinconfig__t.html#a86f86393c4da6d3ef96971f86f7d81c0", null ],
    [ "Pin_PuPd", "struct_g_p_i_o___pinconfig__t.html#ad9ac913fb36fddbe6d13ce61253a3726", null ],
    [ "Pin_speed", "struct_g_p_i_o___pinconfig__t.html#a86f766c3cc3475f8b5e514548ecdea2c", null ]
];