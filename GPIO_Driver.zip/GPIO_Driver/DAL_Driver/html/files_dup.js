var files_dup =
[
    [ "Src", "dir_413f4e031a85da0d68269c6fd2f76e1c.html", "dir_413f4e031a85da0d68269c6fd2f76e1c" ],
    [ "DAL_stm32g4xx.h", "_d_a_l__stm32g4xx_8h.html", "_d_a_l__stm32g4xx_8h" ],
    [ "DAL_stm32g4xx_gpio.h", "_d_a_l__stm32g4xx__gpio_8h.html", "_d_a_l__stm32g4xx__gpio_8h" ]
];