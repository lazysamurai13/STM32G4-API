var annotated_dup =
[
    [ "GPIO_Regdef_t", "struct_g_p_i_o___regdef__t.html", "struct_g_p_i_o___regdef__t" ],
    [ "RCC_Regdef_t", "struct_r_c_c___regdef__t.html", "struct_r_c_c___regdef__t" ]
];