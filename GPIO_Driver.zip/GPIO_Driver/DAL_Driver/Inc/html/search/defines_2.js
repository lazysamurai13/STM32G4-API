var searchData=
[
  ['i2c1_5fpclk_5fen_0',['I2C1_PCLK_EN',['../_dal__stm32g4xx_8h.html#a38b3719d33b55faf15f9b9b08295b353',1,'Dal_stm32g4xx.h']]]
];
