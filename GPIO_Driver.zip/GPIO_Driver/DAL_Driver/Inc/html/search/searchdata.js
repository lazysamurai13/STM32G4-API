var indexSectionsWithContent =
{
  0: "abcdgilmopr",
  1: "gr",
  2: "d",
  3: "abcilmop",
  4: "dgir"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Variables",
  4: "Macros"
};

