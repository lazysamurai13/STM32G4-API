var searchData=
[
  ['pllcfgr_5freg_0',['PLLCFGR_reg',['../struct_r_c_c___regdef__t.html#a979ea168a1189047fe2d714241b1dfbe',1,'RCC_Regdef_t']]],
  ['pupdr_5freg_1',['PUPDR_reg',['../struct_g_p_i_o___regdef__t.html#a0e2086e5b92f3e8ba35cbcd506bce63e',1,'GPIO_Regdef_t']]]
];
